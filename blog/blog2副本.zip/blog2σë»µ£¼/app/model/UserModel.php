<?php
/**
 * Created by PhpStorm.
 * User: xx
 * Date: 17/1/9
 * Time: 21:26
 */

namespace app\model;


class UserModel extends \core\Model
{
    public $table = 'user';
}