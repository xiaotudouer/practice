<?php

// 引入Application类
require 'core/Application.php';

// 执行Application类里的方法
\core\Application::run();